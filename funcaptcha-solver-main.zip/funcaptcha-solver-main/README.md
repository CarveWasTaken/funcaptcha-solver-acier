# Funcaptcha Solver
A funcaptcha audio-based solver that uses google's speech_recognition to solve images. Tested on Roblox's login api,

# Requirements
```bash
requests
termcolor
radnom
string
threading
itertools
speech_recognition
